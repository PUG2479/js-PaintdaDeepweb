function setup() {
  createCanvas(600, 600);
  background('white')
  color = 0
}

function draw() {
  if (color == 1){
    stroke("black");
    fill("black");
  } 
  if (color == 0){
    stroke("white");
    fill("white");
  }
   
  
  if (mouseIsPressed){
      circle(mouseX, mouseY, 20, 20);
      }
  }

 if (keyIsPressed(73) === true){
   color += 1;
 }else{
   color == 0;
 }
